import matplotlib.pyplot as plt
from part_b import curmovielist
from wordcloud import WordCloud

# Function to clean and format the title
def clean_title(title):
    # Split the title by the dot
    parts = title.split('.')
    if len(parts) > 1:
        # Take the second part, remove leading/trailing spaces, replace spaces with underscores, and convert to lowercase
        cleaned_title = parts[1].strip().replace(' ', '_').lower()
        return cleaned_title
    else:
        return title

# Extract cleaned titles
cleaned_titles = [clean_title(entry['Title']) for entry in curmovielist]

# Count frequency of each word
word_counts = {}
for title in cleaned_titles:
    words = title.split('_')
    for word in words:
        if word in word_counts:
            word_counts[word] += 1
        else:
            word_counts[word] = 1

# Generate word cloud
titles_with_spaces = ' '.join(clean_title(entry['Title']) for entry in curmovielist)
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(titles_with_spaces)

# Plot word cloud and frequency graph
plt.figure(figsize=(12, 6))

# Plot word cloud
plt.subplot(1, 2, 1)
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud of Titles')

# Plot frequency graph
plt.subplot(1, 2, 2)
plt.bar(word_counts.keys(), word_counts.values(), color='skyblue')
plt.xlabel('Words')
plt.ylabel('Frequency')
plt.title('Frequency Graph of Titles')
plt.xticks(rotation=45, ha='right')

plt.tight_layout()
plt.show()
