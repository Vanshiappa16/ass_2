from part_a import tv_show_list  # Importing tv_show_list from q3_a.py

# Sorting tv_show_list alphabetically by title
sorted_tv_show_list = sorted(tv_show_list, key=lambda x: x['Title'])

# Get user input
genre = input("Enter genres: ").split()
rating_lower, rating_upper = map(float, input("Enter the range of rating: ").split())
eps_lower, eps_upper = map(int, input("Enter the no. of episodes range: ").split())

# Filter TV shows based on user input
filtered_tv_shows = [
    show for show in sorted_tv_show_list
    if all(g in show['Genres'] for g in genre)
    and rating_lower <= show['Rating'] <= rating_upper
    and eps_lower <= show['NumEpisodes'] <= eps_upper
]

# Sort filtered TV shows by rating in descending order
sorted_filtered_tv_shows = sorted(filtered_tv_shows, key=lambda x: x['Rating'], reverse=True)

# Print the titles of filtered and sorted TV shows
for show in sorted_filtered_tv_shows:
    print(show['Title'])
