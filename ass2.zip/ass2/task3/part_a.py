import requests
from bs4 import BeautifulSoup
import MySQLdb
import re
import matplotlib.pyplot as plt
import numpy as np

# Ensure you have MySQLdb installed, you can install it via pip:
# pip install mysqlclient

headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Firefox/97.0 HP Spectre Laptop'
}
url = "https://www.imdb.com/chart/toptv/"
response = requests.get(url, headers=headers)

if response.status_code == 200:
    soup = BeautifulSoup(response.content, 'html.parser')
    tv_show_containers = soup.find_all(class_='ipc-title__text')
    rating_containers = soup.find_all(class_='ipc-rating-star ipc-rating-star--base ipc-rating-star--imdb ratingGroup--imdb-rating')
    num_episodes_containers = soup.find_all(class_='cli-title-metadata-item')
    script_content = soup.find('script', id='__NEXT_DATA__').text
    script_content = re.findall(r"\"titleGenres.+?TitleGenres\"", script_content)
    for i in range(250):
        script_content[i] = re.findall(r"text\"\:\"(.+?)\"\,", script_content[i])

    tv_show_list = []
    eps = []
    ratings = []

    for entry in rating_containers:
        raw_rating = entry.text.strip()

        rating_s = ""
        if raw_rating:
            for char in raw_rating:
                if char.isdigit() or char == '.':
                    rating_s += char
                elif char.isspace():
                    break

            ratings.append(float(rating_s))
    
    for p in range(len(num_episodes_containers)):
        raw_num_episodes = num_episodes_containers[p].text.strip() if p < len(num_episodes_containers) else ""
        match = re.findall(r'\b(\d+)\s*eps\b', raw_num_episodes)
        if len(match) > 0:
            num_episodes = int(match[0])
            eps.append(num_episodes)

    x = 0
    for i in range(len(tv_show_containers)):
        title = tv_show_containers[i].text

        if title[0].isdigit():
            tv_show_list.append({
                'Title': title,
                'Rating': ratings[x],
                'Genres': script_content[x]
            })
            x += 1

    for tv_show_info, num_episodes in zip(tv_show_list, eps):
        tv_show_info['NumEpisodes'] = num_episodes

    conn = MySQLdb.connect(
        host='localhost',
        user='root',
        passwd='Vanshika1#@',
        db='top_250_shows'
    )

    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tv_shows (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255),
            rating FLOAT,
            genres TEXT,
            num_episodes INT
        )
    ''')

    for tv_show_info in sorted(tv_show_list, key=lambda x: x['Title']):
        cursor.execute('''
        INSERT INTO tv_shows (title, rating, genres, num_episodes)
        VALUES (%s, %s, %s, %s)
        ''', (tv_show_info['Title'], tv_show_info['Rating'], ', '.join(tv_show_info['Genres']), tv_show_info['NumEpisodes']))

    conn.commit()

    cursor.close()
    conn.close()
    
    if __name__ == "__main__":
        # Plotting Number of TV Shows per Genre
        conn = MySQLdb.connect(
            host='localhost',
            user='root',
            passwd='Vanshika1#@',
            db='top_250_shows'
        )

        cursor = conn.cursor()

        cursor.execute("SELECT genres FROM tv_shows")
        data = cursor.fetchall()
        all_genres = [genre.strip() for genres in data for genre in genres[0].split(',')]
        genre_counts = {genre: all_genres.count(genre) for genre in set(all_genres)}

        genres = list(genre_counts.keys())
        counts = list(genre_counts.values())

        plt.bar(genres, counts)
        plt.xlabel('Genres')
        plt.ylabel('Number of TV Shows')
        plt.title('Number of TV Shows per Genre')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.show()

        # Plotting Frequency Count of TV Shows Based on Number of Episodes
        cursor.execute("SELECT num_episodes FROM tv_shows")
        data = cursor.fetchall()
        episode_counts = [num_episodes for num_episodes, in data if num_episodes is not None]
        episode_count_counts = {count: episode_counts.count(count) for count in set(episode_counts)}
        episode_counts_sorted = np.arange(1, max(episode_counts) + 1)
        frequency_counts = [episode_count_counts[count] if count in episode_count_counts else 0 for count in episode_counts_sorted]

        plt.plot(episode_counts_sorted, frequency_counts, marker='o')
        plt.xlabel('Number of Episodes')
        plt.ylabel('Frequency Count')
        plt.title('Frequency Count of TV Shows Based on Number of Episodes')
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        cursor.close()
        conn.close()
else:
    print(f"Failed to retrieve the page. Status code: {response.status_code}")
