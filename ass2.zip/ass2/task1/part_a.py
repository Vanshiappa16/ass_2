import time

def middle_square(seed):
    # Square the seed and convert it to a string
    squared = str(seed * seed)
    
    # Pad the squared number with zeros if its length is less than 8
    squared = squared.zfill(8)
    
    # Extract the middle 4 digits
    middle_index = len(squared) // 2 - 2
    middle_digits = squared[middle_index:middle_index + 4]
    
    # Return the middle digits as the next seed
    return int(middle_digits)

def pseudo_rand_num_gen(seed, k):
    # List to store the generated pseudo-random numbers
    pseudo_random_numbers = []
    
    # Generate k pseudo-random numbers
    for _ in range(k):
        seed = middle_square(seed)
        pseudo_random_numbers.append(seed)
    
    return pseudo_random_numbers

# Take input from user for k and seed
k = int(input("Enter the number of pseudo-random numbers to generate: "))
seed = int(input("Enter the seed (a 4-digit number): "))

# Check if seed is a 4-digit number
if seed < 1000 or seed > 9999:
    print("Error: Seed must be a 4-digit number.")
else:
    # Generate pseudo-random numbers
    random_numbers = pseudo_rand_num_gen(seed, k)
    print("Generated pseudo-random numbers:", random_numbers)
