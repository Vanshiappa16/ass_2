import matplotlib.pyplot as plt
from part_a import pseudo_rand_num_gen
import random

def estimate_pi(num_points, seed):
    inside_circle = 0
    pi_values = []
    for _ in range(num_points):
        x = pseudo_rand_num_gen(seed, 1)[0] / 10000.0
        y = pseudo_rand_num_gen(seed, 1)[0] / 10000.0
        if x**2 + y**2 <= 1:
            inside_circle += 1
        pi_estimate = 4 * inside_circle / (len(pi_values) + 1)
        pi_values.append(pi_estimate)
    return pi_values

def plot_pi_estimation(pi_values):
    plt.plot(pi_values)
    plt.xlabel('Iterations')
    plt.ylabel('Estimated Value of Pi')
    plt.title('Estimation of Pi using Monte Carlo Simulation')
    plt.show()

if __name__ == "__main__":
    seed = int(input("Enter the seed (a 4-digit number): "))
    num_points = 10000  # Increased the number of points for better accuracy
    pi_values = estimate_pi(num_points, seed)
    final_pi_estimate = pi_values[-1]
    print("Approximate value of pi:", final_pi_estimate)
    plot_pi_estimation(pi_values)
