import cv2 as cv
import matplotlib.pyplot as plt

def display_image(img, title=None):
    plt.imshow(cv.cvtColor(img, cv.COLOR_BGR2RGB))
    if title:
        plt.title(title)
    plt.show()

img = cv.imread('1.png')

height, width, _ = img.shape
left_half = img[:, :width//2]

display_image(left_half, title='Left Half of the image')
